<div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
    <!--[if BLOCK]><![endif]--><?php if(session('success')): ?>
        <div class="bg-emerald-500 text-white alert-success">
            <div class=" flex justify-between mx-auto py-2 sm:px-4 lg:px-6">
                <p class=""><?php echo e(session('success')); ?></p>
            </div>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    <div class=" p-6 text-gray-900 dark:text-gray-100 space-y-4">
        <h1 class="font-black text-lg"><?php echo e($formTitle); ?></h1>
        <div class="space-y-4">
            <!--[if BLOCK]><![endif]--><?php if($this->form->editMode): ?>
                
                <button  wire:loading.remove class=" px-4 py-2  font-medium rounded-lg border border-slate-500 dark:text-white" wire:click="clearForm">Cancel Edit Mode</button>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            <form wire:submit="<?php echo e($this->form->editMode ? "update" : "store"); ?>">
                <div class="mb-3">
                    <label 
                        for="title"
                        class="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                    >Title</label>
                    <input type="text" wire:model="form.title" id="title" class="bg-gray-50 border border-gray-300 text-sm font-medium rounded-lg text-gray-900 dark:text-white focus:ring-blue-500 w-full">
                    <div class="">
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['form.title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-red-500 text-sm"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>
                <div class="mb-3">
                    <label 
                        for="slug"
                        class="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                    >Slug</label>
                    <input type="text" wire:model="form.slug" id="slug" class="bg-gray-50 border border-gray-300 text-sm font-medium rounded-lg text-gray-900 dark:text-white focus:ring-blue-500 w-full">
                    <div class="">
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['form.slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-red-500 text-sm"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>
                <div class="mb-3">
                    <label 
                        for="description"
                        class="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                    >Description</label>
                    <textarea  wire:model="form.description"  id="description" class="bg-gray-50 border border-gray-300 text-sm font-medium rounded-lg text-gray-900 dark:text-white focus:ring-blue-500 w-full"></textarea>
                    <div class="">
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['form.description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-red-500 text-sm"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>
                <div class="mb-3">
                    <label 
                        for="status"
                        class="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                    >Status</label>
                    <select  wire:model="form.status" id="status" class="bg-gray-50 border border-gray-300 text-sm font-medium rounded-lg text-gray-900 dark:text-white focus:ring-blue-500 w-full">
                        <option value=""></option>
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = \App\Enums\StatusType::cases(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($status->value); ?>"><?php echo e($status->value); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    </select>
                    <div class="">
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['form.status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-red-500 text-sm"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>
                <div class="mb-3">
                    <label 
                        for="priority"
                        class="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                    >Priority</label>
                    <select  wire:model="form.priority" id="priority" class="bg-gray-50 border border-gray-300 text-sm font-medium rounded-lg text-gray-900 dark:text-white focus:ring-blue-500 w-full">
                        <option value=""></option>
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = \App\Enums\PriorityType::cases(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $priority): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($priority->value); ?>"><?php echo e($priority->value); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    </select>
                    <div class="">
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['form.priority'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-red-500 text-sm"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>
                <div class="mb-3">
                    <label 
                        for="deadline"
                        class="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                    >Deadline</label>
                    <input  wire:model="form.deadline" type="datetime-local" id="deadline" class="bg-gray-50 border border-gray-300 text-sm font-medium rounded-lg text-gray-900 dark:text-white focus:ring-blue-500 w-full">
                    <div class="">
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['form.deadline'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-red-500 text-sm"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>
                <!--[if BLOCK]><![endif]--><?php if($this->form->editMode): ?>
                    <div class="mb-3 flex justify-end gap-2">
                        
                        <button type="submit" wire:loading.remove class="bg-indigo-500 px-4 py-2  font-medium rounded-lg text-white dark:text-white ">Update</button>
                        <button type="button" wire:loading class="bg-indigo-500 opacity-80 px-4 py-2  font-medium rounded-lg text-white dark:text-white " disabled>Updating Task ...</button>
                    </div>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                <!--[if BLOCK]><![endif]--><?php if(!$this->form->editMode): ?>
                    <div class="mb-3 flex justify-end">
                        <button type="submit" wire:loading.remove class="bg-indigo-500 px-4 py-2  font-medium rounded-lg text-white dark:text-white ">Submit</button>
                        <button type="button" wire:loading class="bg-indigo-500 opacity-80 px-4 py-2  font-medium rounded-lg text-white dark:text-white " disabled>Saving Task ...</button>
                    </div>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                
        </form>
    </div>
</div>
</div><?php /**PATH D:\Programming\Web and Mobile Apps\Learn\Laravel\breeze-livewire\resources\views/livewire/tasks/tasks-form.blade.php ENDPATH**/ ?>