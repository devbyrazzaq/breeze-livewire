<div class="  text-gray-900 dark:text-gray-100  bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
    <!--[if BLOCK]><![endif]--><?php if(session('success')): ?>
        <div class="bg-emerald-500 text-white alert-success">
            <div class=" flex justify-between mx-auto py-2 sm:px-4 lg:px-6">
                <p class=""><?php echo e(session('success')); ?></p>
            </div>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    <div class="p-6 space-y-4">

            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('tasks.tasks-count', ['tasksCount' => $this->tasksCount,'tasksCountByStatus' => $this->tasksCountByStatus]);

$__html = app('livewire')->mount($__name, $__params, 'lw-1500571933-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $this->tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>        
                <div class="p-4 rounded-lg shadow-lg bg-white border border-slate-300 space-y-4">
                    <div class="flex justify-between items-center">
                        <h1><?php echo e($task->title); ?></h1>
                        <p class="text-sm"><?php echo e($task->created_at->diffForHumans()); ?></p>
                    </div>
                    <div class="text-sm">
                        <p class="font-bold">Deadline : <?php echo e($task->deadline->diffForHumans()); ?></p>
                        <p class="text-slate-700 "><?php echo e($task->description); ?></p>
                    </div>
                    <div class="flex justify-between">
                        <div class="">
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = App\Enums\StatusType::cases(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $case): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <button type="button"
                                    wire:click="changeStatus(<?php echo e($task->id); ?>, '<?php echo e($case->value); ?>')"
                                    class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                                        'inline-flex items-center px-4 py-2 bg-white border rounded-md font-semibold text-xs text-gray-700 uppercase tracking-widest shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 disabled:opacity-25 transition ease-in-out duration-150',
                                        $case->color() => true,
                                    ]); ?>"
                                    <?php echo e($case->value == $task->status->value ? 'disabled' : ''); ?>>
                                    <?php echo e($case->value); ?>

                                </button>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <div class="">
                            <button type="button" wire:click="$dispatch('edit-task', {id:<?php echo e($task->id); ?>})" class="text-sm px-4 py-2  rounded-lg  border border-slate-500 hover:opacity-80" >Edit</button>
                            <button type="button" wire:click="destroy(<?php echo e($task->id); ?>)" wire:confirm="Are you sure you want to delete this post?" class="text-sm px-4 py-2  rounded-lg bg-red-600 border border-red-600 text-white hover:opacity-80" >Delete</button>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            <div class="mt-2 mb-12 p-2">
                <?php echo e($this->tasks->links()); ?>

            </div>
        </div>
    </div>
</div><?php /**PATH D:\Programming\Web and Mobile Apps\Learn\Laravel\breeze-livewire\resources\views/livewire/tasks/tasks-list.blade.php ENDPATH**/ ?>