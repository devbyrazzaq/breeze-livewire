 <div class="">
         <?php $__env->slot('header', null, []); ?> 
            <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
                <?php echo e($pageTitle); ?>

            </h2>
         <?php $__env->endSlot(); ?>
    
        <div class="py-12">
            <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
                <div class="grid grid-cols-3 gap-4">
                    <div class="col-span-2">
                        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('tasks.tasks-list', ['lazy' => true]);

$__html = app('livewire')->mount($__name, $__params, 'lw-2737450635-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                    </div>
                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('tasks.tasks-form', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-2737450635-1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                </div>
            </div>
        </div>

</div>

<?php /**PATH D:\Programming\Web and Mobile Apps\Learn\Laravel\breeze-livewire\resources\views/livewire/tasks/tasks-index.blade.php ENDPATH**/ ?>