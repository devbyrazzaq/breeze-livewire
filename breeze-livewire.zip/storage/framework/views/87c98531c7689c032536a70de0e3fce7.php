<div class="" x-data="{
    showModal:false,
    handleKeydown(e){
        if(e.keyCode == 191) {
            this.showModal = true
        }

        if(e.keyCode == 27) {
            this.showModal = false;
            $wire.search = ''
        }
    }, 


}">
    <button @click="showModal = true" type="button"
        class="flex space-x-3 py-2 px-4 my-2 outline-none border-b border-slate-200" 
        @keydown.window="handleKeydown"
       
        >
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"
            class="w-6 h-6">
            <path stroke-linecap="round" stroke-linejoin="round"
                d="M21 21l-5.197-5.197m0 0A7.5 7.5 0 105.196 5.196a7.5 7.5 0 0010.607 10.607z" />
        </svg>
        <span class="pr-6">Search</span>
    </button>
    
    <template x-teleport="<?php echo e('body'); ?>">
    <div x-show="showModal" 
        x-trap="showModal"
        x-tansition:enter="transition ease-out duration-300"  
        x-transition:enter-start="opacity-0"
        x-transition:enter-end="opacity-100" 
        x-transition:leave="transition ease-in duration-300"
        x-transition:leave-start="opacity-100"
        x-transition:leave-end="opacity-0 "
        
        class="relative z-10" 
        aria-labelledby="modal-title" 
        role="dialog" 
        aria-modal="true">
        <!--
          Background backdrop, show/hide based on modal state.
      
          Entering: "ease-out duration-300"
            From: "opacity-0"
            To: "opacity-100"
          Leaving: "ease-in duration-200"
            From: "opacity-100"
            To: "opacity-0"
        -->
        <div class="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity"></div>
      
        <div  class="fixed inset-0 z-10 w-screen overflow-y-auto">
          <div class="flex items-end justify-center p-4 text-center sm:items-center sm:p-0">
            <!--
              Modal panel, show/hide based on modal state.
      
              Entering: "ease-out duration-300"
                From: "opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
                To: "opacity-100 translate-y-0 sm:scale-100"
              Leaving: "ease-in duration-200"
                From: "opacity-100 translate-y-0 sm:scale-100"
                To: "opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
            -->
            <div @click.outside="showModal = false" 
              
                class="relative transform p-6 rounded-lg bg-white text-left shadow-xl transition-all sm:my-8 sm:w-full sm:max-w-lg"
            >
                <div class="relative " x-data="{
                    searchPosts(event){
                        document.getElementById('search').focus();
                        event.preventDefault();
                    }
                }">
                    <input wire:model.live.throttle.500ms="search" @keydown.ctrl.slash.window="searchPosts" id="search" type="text" placeholder="Start typing.. or click - SHIFT + / - to search"  class="block w-full flex-1 py-2 px-3 mt-2 outline-none border-none rounded-md bg-slate-100"/>
                    <div class="absolute mt-2 z-20 w-full overflow-hidden rounded-md bg-slate-50 shadow-2xl">
                        <!--[if BLOCK]><![endif]--><?php if(Str::length($this->search) > 0): ?>
                            <div class="p-2 text-xs text-slate-500">
                            
                                <!--[if BLOCK]><![endif]--><?php if(count($results) == 0): ?>
                                    <p>Nothing task found..</p>
                                <?php else: ?>
                                    <p>found <?php echo e(count($results)); ?> task</p>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            </div>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="cursor-pointer py-2 px-3 hover:bg-slate-100">
                            <p class="text-sm font-bold text-gray-600"><?php echo e($result->title); ?></p>
                            <p class="text-sm italic text-gray-600"><?php echo e(Str::limit($result->description, 100, '...')); ?></p>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>
              
              
            </div>
          </div>
        </div>
      </div>
      
    </template>

    
</div>
<?php /**PATH D:\Programming\Web and Mobile Apps\Learn\Laravel\breeze-livewire\resources\views/livewire/search.blade.php ENDPATH**/ ?>