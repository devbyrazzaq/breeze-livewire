<div>
    <h1 class="  text-xl font-bold">Taks List - <?php echo e($tasksCount); ?> task</h1>
    <div class="flex justify-center mt-4">
        <div class="w-8/12 p-4 flex justify-between rounded-md bg-slate-200 shadow-md">
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $tasksCountByStatus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="flex flex-col justify-center items-center">
                    <span class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                        'w-16 h-16 flex justify-center items-center rounded-full text-lg text-black border-4 border-slate-500 ',
                        $status->status->color() => $status->status,
                    ]); ?>">
                        <?php echo e($status->count); ?>

                    </span>
                    <span><?php echo e($status->status->value); ?></span>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        </div>
    </div>
</div>
<?php /**PATH D:\Programming\Web and Mobile Apps\Learn\Laravel\breeze-livewire\resources\views/livewire/tasks/tasks-count.blade.php ENDPATH**/ ?>