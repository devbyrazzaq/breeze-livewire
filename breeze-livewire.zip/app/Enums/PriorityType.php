<?php

namespace App\Enums;

enum PriorityType: string
{

    case LOW = 'LOW';

    case NORMAL = 'NORMAL';

    case HIGH = 'HIGH';
}
