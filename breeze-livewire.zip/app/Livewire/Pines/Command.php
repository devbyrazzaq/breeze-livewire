<?php

namespace App\Livewire\Pines;

use Livewire\Component;

class Command extends Component
{
    public function render()
    {
        return view('livewire.pines.command');
    }
}
