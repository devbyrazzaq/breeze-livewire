<?php

namespace App\Livewire\Pines;

use Livewire\Component;

class DropdownMenu extends Component
{
    public function render()
    {
        return view('livewire.pines.dropdown-menu');
    }
}
