<?php

namespace App\Livewire\Pines;

use Livewire\Component;

class Banner extends Component
{
    public function render()
    {
        return view('livewire.pines.banner');
    }
}
