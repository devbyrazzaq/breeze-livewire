<?php

namespace App\Livewire\Pines;

use Livewire\Component;

class Accordion extends Component
{
    public function render()
    {
        return view('livewire.pines.accordion');
    }
}
